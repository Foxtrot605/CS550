﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ATM3
{
    public partial class ATMMAINPAGE : System.Web.UI.Page
    {
        protected String TBalance = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            string JQueryVer = "1.7.1";
            ScriptManager.ScriptResourceMapping.AddDefinition("jquery", new ScriptResourceDefinition
            {
                Path = "~/Scripts/jquery-" + JQueryVer + ".min.js",
                DebugPath = "~/Scripts/jquery-" + JQueryVer + ".js",
                CdnPath = "http://ajax.aspnetcdn.com/ajax/jQuery/jquery-" + JQueryVer + ".min.js",
                CdnDebugPath = "http://ajax.aspnetcdn.com/ajax/jQuery/jquery-" + JQueryVer + ".js",
                CdnSupportsSecureConnection = true,
                LoadSuccessExpression = "window.jQuery"
            });
            var cs = Properties.Settings.Default.ConnectionString;

            ErrorMessage.Text = "";
            
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                var Username = Server.UrlDecode(Request.QueryString["Username"].ToString());
                String FName = "";
                String LName = "";
                String Balance = "0";
                int Account = 0;

                using (var cmd = new SqlCommand("SELECT AccountID, Balance, FirstName, LastName FROM ATMTABLE WHERE Username = @Username", con))
                {
                    cmd.Parameters.AddWithValue("@Username", Username);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read()) // Don't assume we have any rows.
                        {
                            int ord = reader.GetOrdinal("FirstName");
                            FName = reader.GetString(ord); // Handles nulls and empty strings.
                            ord = reader.GetOrdinal("LastName");
                            LName = reader.GetString(ord);
                            ord = reader.GetOrdinal("AccountID");
                            Account = reader.GetInt32(ord);
                            ord = reader.GetOrdinal("Balance");
                            Balance = reader.GetString(ord);
                        }

                        FNameText.Text = FName;
                        LNameText.Text = LName;
                        AccountText.Text = Account.ToString();
                        BalanceText.Text = Balance;
                        TBalance = Balance;
                    }
                }

                con.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e) // Withdraw
        {
            int Withdraw = Convert.ToInt32(WithText.Text);
            int Balance = Convert.ToInt32(TBalance);
            if (Withdraw > Balance)
            {
                ErrorMessage.Text = "You Do Not Have Enough In Your Account";
            }
            else if (Withdraw < 0)
            {
                ErrorMessage.Text = "Cannot Withdraw Negative Ammount";
            }
            else
            {
                Balance = Balance - Withdraw;
                TBalance = Balance.ToString();
                BalanceText.Text = TBalance;
                WithText.Text = "";
                ErrorMessage.Text = Balance.ToString();
            }
        }

        protected void Button2_Click(object sender, EventArgs e) // Deposit
        {
            int Deposit = Convert.ToInt32(DepText.Text);
            int Balance = Convert.ToInt32(TBalance);
            if (Deposit < 0)
            {
                ErrorMessage.Text = "Cannot Deposit Negative Ammount";
            }
            else
            {
                Balance = Balance + Deposit;
                TBalance = Balance.ToString();
                BalanceText.Text = TBalance;
                DepText.Text = "";
                ErrorMessage.Text = Balance.ToString();
            }
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            var cs = Properties.Settings.Default.ConnectionString;

            ErrorMessage.Text = "";

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                var Username = Server.UrlDecode(Request.QueryString["Username"].ToString());

                using (var cmd = new SqlCommand("UPDATE ATMTABLE SET Balance = @Balance WHERE Username = @Username", con))
                {
                    cmd.Parameters.AddWithValue("@Balance", BalanceText.Text);
                    cmd.Parameters.AddWithValue("@Username", Username);
                    cmd.ExecuteNonQuery();
                }

                con.Close();
                con.Open();

                using (var cmd2 = new SqlCommand("SELECT AccountID, Balance, FirstName, LastName FROM ATMTABLE WHERE Username = @Username", con)) 
                { 
                    cmd2.Parameters.AddWithValue("@Username", Username);

                    String FName = "";
                    String LName = "";
                    int Account = 0;
                    String Balance = "";

                    using (var reader = cmd2.ExecuteReader())
                    {
                        if (reader.Read()) // Don't assume we have any rows.
                        {
                            int ord = reader.GetOrdinal("FirstName");
                            FName = reader.GetString(ord); // Handles nulls and empty strings.
                            ord = reader.GetOrdinal("LastName");
                            LName = reader.GetString(ord);
                            ord = reader.GetOrdinal("AccountID");
                            Account = reader.GetInt32(ord);
                            ord = reader.GetOrdinal("Balance");
                            Balance = reader.GetString(ord);
                        }

                        FNameText.Text = FName;
                        LNameText.Text = LName;
                        AccountText.Text = Account.ToString();
                        BalanceText.Text = Balance;
                    }
                }

                con.Close();
            }

        }
    }
}