﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ATM3
{
    public partial class ATMLOGIN : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string JQueryVer = "1.7.1";
            ScriptManager.ScriptResourceMapping.AddDefinition("jquery", new ScriptResourceDefinition
            {
                Path = "~/Scripts/jquery-" + JQueryVer + ".min.js",
                DebugPath = "~/Scripts/jquery-" + JQueryVer + ".js",
                CdnPath = "http://ajax.aspnetcdn.com/ajax/jQuery/jquery-" + JQueryVer + ".min.js",
                CdnDebugPath = "http://ajax.aspnetcdn.com/ajax/jQuery/jquery-" + JQueryVer + ".js",
                CdnSupportsSecureConnection = true,
                LoadSuccessExpression = "window.jQuery"
            });

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var cs = Properties.Settings.Default.ConnectionString;

            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                using (var cmd = new SqlCommand("SELECT Password FROM ATMTABLE WHERE Username = @Username", con))
                {
                    cmd.Parameters.AddWithValue("@Username", UTextBox.Text);

                    var cmd2 = new SqlCommand("SELECT Username FROM ATMTABLE WHERE Password = @Password", con);

                    cmd2.Parameters.AddWithValue("@Password", PTextBox.Text);

                    var password = cmd.ExecuteScalar();
                    var username = cmd2.ExecuteScalar();

                    if (username != null && password !=null)
                    {
                        Response.Redirect("ATMMAINPAGE.aspx?Username=" + username);
                    }
                    else
                    {
                        ErrorLabel.Text = "Invalid Username or Password";
                    }
                }

                con.Close();
            }

        }
    
    }
}